/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Controller.proxy32;
import View.Vista3;
import java.io.File;

/**
 *
 * @author Acer
 */
public class Modelo3 {

    private Vista3 vista3;
    private String ruta;

    public Modelo3(Vista3 vista3, String ruta) {
        this.vista3 = vista3;
        this.ruta = ruta;
    }

    public boolean nuevo_usuario(String name) {
      
        this.ruta = this.ruta+name+".txt";
        
        File file = new File(ruta);
        // Si el archivo no existe el usuario es aceptado
        if(!file.exists()) {
            return true;
        }
        
        return false;
    }

    public String getRuta() {
        return ruta;
    }
}
