/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import View.Vista2;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Acer
 */
public class Modelo2 {
    
    private String ruta;
    private Vista2 vista2;

    public Modelo2(Vista2 vista2) {
        this.vista2 = vista2;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }      
    
    public void nombres(){
        this.vista2.s1.addItem("QATAR");
        this.vista2.s1.addItem("ECUADOR");
        this.vista2.s1.addItem("SENEGAL");
        this.vista2.s1.addItem("HOLANDA");
        this.vista2.s2.addItem("INGLATERRA");
        this.vista2.s2.addItem("IRAN");
        this.vista2.s2.addItem("EEUU");
        this.vista2.s2.addItem("GALES");
        this.vista2.s3.addItem("ARGENTINA");
        this.vista2.s3.addItem("ARABIA");
        this.vista2.s3.addItem("MEXICO");
        this.vista2.s3.addItem("POLONIA");
        this.vista2.s4.addItem("FRANCIA");
        this.vista2.s4.addItem("AUSTRALIA");
        this.vista2.s4.addItem("DINAMARCA");
        this.vista2.s4.addItem("TUNEZ");
        this.vista2.s5.addItem("ESPAÑA");
        this.vista2.s5.addItem("COSTA RICA");
        this.vista2.s5.addItem("ALEMANIA");
        this.vista2.s5.addItem("JAPON");
        this.vista2.s6.addItem("BELGICA");
        this.vista2.s6.addItem("CANADA");
        this.vista2.s6.addItem("MARRUECOS");
        this.vista2.s6.addItem("CROACIA");
        this.vista2.s7.addItem("BRASIL");
        this.vista2.s7.addItem("SERBIA");
        this.vista2.s7.addItem("SUIZA");
        this.vista2.s7.addItem("CAMERUN");
        this.vista2.s8.addItem("PORTUGAL");
        this.vista2.s8.addItem("GHANA");
        this.vista2.s8.addItem("URUGUAY");
        this.vista2.s8.addItem("COREA");
        this.vista2.s9.addItem("QATAR");
        this.vista2.s9.addItem("ECUADOR");
        this.vista2.s9.addItem("SENEGAL");
        this.vista2.s9.addItem("HOLANDA");
        this.vista2.s10.addItem("INGLATERRA");
        this.vista2.s10.addItem("IRAN");
        this.vista2.s10.addItem("EEUU");
        this.vista2.s10.addItem("GALES");
        this.vista2.s11.addItem("ARGENTINA");
        this.vista2.s11.addItem("ARABIA");
        this.vista2.s11.addItem("MEXICO");
        this.vista2.s11.addItem("POLONIA");
        this.vista2.s12.addItem("FRANCIA");
        this.vista2.s12.addItem("AUSTRALIA");
        this.vista2.s12.addItem("DINAMARCA");
        this.vista2.s12.addItem("TUNEZ");
        this.vista2.s13.addItem("ESPAÑA");
        this.vista2.s13.addItem("COSTA RICA");
        this.vista2.s13.addItem("ALEMANIA");
        this.vista2.s13.addItem("JAPON");
        this.vista2.s14.addItem("BELGICA");
        this.vista2.s14.addItem("CANADA");
        this.vista2.s14.addItem("MARRUECOS");
        this.vista2.s14.addItem("CROACIA");
        this.vista2.s15.addItem("BRASIL");
        this.vista2.s15.addItem("SERBIA");
        this.vista2.s15.addItem("SUIZA");
        this.vista2.s15.addItem("CAMERUN");
        this.vista2.s16.addItem("PORTUGAL");
        this.vista2.s16.addItem("GHANA");
        this.vista2.s16.addItem("URUGUAY");
        this.vista2.s16.addItem("COREA");
    }

    public boolean comprobar() {
        
        if(this.vista2.s1.getSelectedItem()==this.vista2.s9.getSelectedItem() ||
           this.vista2.s2.getSelectedItem()==this.vista2.s10.getSelectedItem() ||
           this.vista2.s3.getSelectedItem()==this.vista2.s11.getSelectedItem() ||
           this.vista2.s4.getSelectedItem()==this.vista2.s12.getSelectedItem() ||
           this.vista2.s5.getSelectedItem()==this.vista2.s13.getSelectedItem() ||
           this.vista2.s6.getSelectedItem()==this.vista2.s14.getSelectedItem() ||
           this.vista2.s7.getSelectedItem()==this.vista2.s15.getSelectedItem() ||
           this.vista2.s8.getSelectedItem()==this.vista2.s16.getSelectedItem())
        {
            return false;
        }
        
        return true;
    }
    
    public void calificar_octavos(){
        
        ArrayList<JTextField> txts = new ArrayList<>();
        
        txts.add(this.vista2.o1);
        txts.add(this.vista2.o11);
        txts.add(this.vista2.o2);
        txts.add(this.vista2.o22);
        txts.add(this.vista2.o3);
        txts.add(this.vista2.o33);
        txts.add(this.vista2.o4);
        txts.add(this.vista2.o44);
        txts.add(this.vista2.o5);
        txts.add(this.vista2.o55);
        txts.add(this.vista2.o6);
        txts.add(this.vista2.o66);
        txts.add(this.vista2.o7);
        txts.add(this.vista2.o77);
        txts.add(this.vista2.o8);
        txts.add(this.vista2.o88);
        
        ArrayList<String> pais = new ArrayList<>();
        pais.add((String) this.vista2.s1.getSelectedItem());
        pais.add((String) this.vista2.s2.getSelectedItem());
        pais.add((String) this.vista2.s3.getSelectedItem());
        pais.add((String) this.vista2.s4.getSelectedItem());
        pais.add((String) this.vista2.s5.getSelectedItem());
        pais.add((String) this.vista2.s6.getSelectedItem());
        pais.add((String) this.vista2.s7.getSelectedItem());
        pais.add((String) this.vista2.s8.getSelectedItem());
        
        ArrayList<JLabel> lbls = new ArrayList<>();
        
        lbls.add(this.vista2.lblc1);
        lbls.add(this.vista2.lblc2);
        lbls.add(this.vista2.lblc3);
        lbls.add(this.vista2.lblc4);
        
        int j = 0; //controla en que lbl esta
        int k = 0;
        
        for(int i=0; i<txts.size()-1;i+=4)
        {
            if(Integer.parseInt(txts.get(i).getText()) > Integer.parseInt(txts.get(i+2).getText()))
            {
                lbls.get(j).setText(pais.get(k));
            }
            else if(Integer.parseInt(txts.get(i).getText()) < Integer.parseInt(txts.get(i+2).getText()))
            {
                lbls.get(j).setText(pais.get(k+1));
            }
            else
            {
                if(Integer.parseInt(txts.get(i+1).getText()) > Integer.parseInt(txts.get(i+3).getText()))
                {
                    lbls.get(j).setText(pais.get(k));
                }
                else if(Integer.parseInt(txts.get(i+1).getText()) < Integer.parseInt(txts.get(i+3).getText()))
                {
                    lbls.get(j).setText(pais.get(k+1));
                }
                else
                {
                    Integer.parseInt(null);
                }
            }
            
            j++;
            k+=2;
        }
        
    }
}
