/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import View.Vista1;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Acer
 */
public class Modelo1 {
    
    private Vista1 vista1;
    private ArrayList<String> selecciones;
    private ArrayList<String> grupo;
    
    public Modelo1(Vista1 vista1) {
        this.vista1=vista1;
        this.grupo = crear_grupos();
        this.selecciones = crear_paises();
    }
    
    //Establece los nombres de los equipos pertenecientes a cada grupo en la vista
    public void grupo(int i, int j) {
        this.vista1.lblgrupo.setText(this.grupo.get(j));
        this.vista1.enfrentamiento11.setText(selecciones.get(i));
        this.vista1.enfrentamiento12.setText(selecciones.get(i+1));
        this.vista1.enfrentamiento21.setText(selecciones.get(i));
        this.vista1.enfrentamiento22.setText(selecciones.get(i+2));
        this.vista1.enfrentamiento31.setText(selecciones.get(i));
        this.vista1.enfrentamiento32.setText(selecciones.get(i+3));
        this.vista1.enfrentamiento41.setText(selecciones.get(i+1));
        this.vista1.enfrentamiento42.setText(selecciones.get(i+2));
        this.vista1.enfrentamiento51.setText(selecciones.get(i+1));
        this.vista1.enfrentamiento52.setText(selecciones.get(i+3));
        this.vista1.enfrentamiento61.setText(selecciones.get(i+2));
        this.vista1.enfrentamiento62.setText(selecciones.get(i+3));
    }
    
    //Comprueba que todos los txt sean numeros enteros
    public boolean comprobar(){
        
        try
        {
            Integer.parseInt(this.vista1.txt11.getText());
            Integer.parseInt(this.vista1.txt12.getText());
            Integer.parseInt(this.vista1.txt21.getText());
            Integer.parseInt(this.vista1.txt22.getText());
            Integer.parseInt(this.vista1.txt31.getText());
            Integer.parseInt(this.vista1.txt32.getText());
            Integer.parseInt(this.vista1.txt41.getText());
            Integer.parseInt(this.vista1.txt42.getText());
            Integer.parseInt(this.vista1.txt51.getText());
            Integer.parseInt(this.vista1.txt52.getText());
            Integer.parseInt(this.vista1.txt61.getText());
            Integer.parseInt(this.vista1.txt62.getText());
        }
        catch(NumberFormatException e)
        {
            JOptionPane.showMessageDialog(null, "Debe ingresar numeros enteros", "Error!", JOptionPane.ERROR_MESSAGE);
            return false;
        }
            
        return true;
    }
    //Establese el nombre de los grupos existentes
    private ArrayList<String> crear_grupos() {
        ArrayList<String> grupos = new ArrayList();
        grupos.add("GRUPO A");
        grupos.add("GRUPO B");
        grupos.add("GRUPO C");
        grupos.add("GRUPO D");
        grupos.add("GRUPO E");
        grupos.add("GRUPO F");
        grupos.add("GRUPO G");
        grupos.add("GRUPO H");
        return grupos;
    }

    public ArrayList<String> crear_paises(){
        
        ArrayList<String> paises = new ArrayList<>();
        paises.add("QATAR");
        paises.add("ECUADOR");
        paises.add("SENEGAL");
        paises.add("HOLANDA");
        paises.add("INGLATERRA");
        paises.add("IRAN");
        paises.add("EEUU");
        paises.add("GALES");
        paises.add("ARGENTINA");
        paises.add("ARABIA");
        paises.add("MEXICO");
        paises.add("POLONIA");
        paises.add("FRANCIA");
        paises.add("AUSTRALIA");
        paises.add("DINAMARCA");
        paises.add("TUNEZ");
        paises.add("ESPAÑA");
        paises.add("COSTA RICA");
        paises.add("ALEMANIA");
        paises.add("JAPON");
        paises.add("BELGICA");
        paises.add("CANADA");
        paises.add("MARRUECOS");
        paises.add("CROACIA");
        paises.add("BRASIL");
        paises.add("SERBIA");
        paises.add("SUIZA");
        paises.add("CAMERUN");
        paises.add("PORTUGAL");
        paises.add("GHANA");
        paises.add("URUGUAY");
        paises.add("COREA");
        return paises;
    }
    
    //Limpia las cajas de texto para la siguiente vista
    public void limpiartxt() {
        this.vista1.txt11.setText("");
        this.vista1.txt12.setText("");
        this.vista1.txt21.setText("");
        this.vista1.txt22.setText("");
        this.vista1.txt31.setText("");
        this.vista1.txt32.setText("");
        this.vista1.txt41.setText("");
        this.vista1.txt42.setText("");
        this.vista1.txt51.setText("");
        this.vista1.txt52.setText("");
        this.vista1.txt61.setText("");
        this.vista1.txt62.setText("");
    }

    public void guardar(int i, String nombre) {
        
        try {
            String ruta = "C:\\Users\\Acer\\Desktop\\preddicciones/"+nombre+".txt";
            String contenido = selecciones.get(i)+","+this.vista1.txt11.getText()+","+this.vista1.txt12.getText()+","+selecciones.get(i+1)+"\n"
                              +selecciones.get(i)+","+this.vista1.txt21.getText()+","+this.vista1.txt22.getText()+","+selecciones.get(i+2)+"\n"
                              +selecciones.get(i)+","+this.vista1.txt31.getText()+","+this.vista1.txt32.getText()+","+selecciones.get(i+3)+"\n"
                              +selecciones.get(i+1)+","+this.vista1.txt41.getText()+","+this.vista1.txt42.getText()+","+selecciones.get(i+2)+"\n"
                              +selecciones.get(i+1)+","+this.vista1.txt51.getText()+","+this.vista1.txt52.getText()+","+selecciones.get(i+3)+"\n"
                              +selecciones.get(i+2)+","+this.vista1.txt61.getText()+","+this.vista1.txt62.getText()+","+selecciones.get(i+3)+"\n";
           
            File file = new File(ruta);
            // Si el archivo no existe es creado
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(contenido);
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
