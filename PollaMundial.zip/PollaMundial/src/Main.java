
import Controller.Controlador1;
import Controller.Controlador2;
import Controller.Controlador3;
import Controller.proxy12;
import Controller.proxy13;
import Controller.proxy32;
import Model.Modelo1;
import Model.Modelo2;
import Model.Modelo3;
import View.Vista1;
import View.Vista2;
import View.Vista3;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Acer
 */
public class Main {
    
    public static void main(String args[]){
        
        String ruta = "C:\\Users\\Acer\\Desktop\\preddicciones/";     
        
        //Se crean las vistas
        Vista1 vista1 = new Vista1();
        Vista2 vista2 = new Vista2();
        Vista3 vista3 = new Vista3();
       
        //Se crean los modelos con sus respectivas vistas
        Modelo1 modelo1 = new Modelo1(vista1);
        Modelo2 modelo2 = new Modelo2(vista2);
        Modelo3 modelo3 = new Modelo3(vista3,ruta);
        
        //Se crean los proxy
        proxy12 prox1_2 = new proxy12(vista1,vista2);
        proxy13 prox1_3 = new proxy13(vista1,vista3);
        proxy32 prox3_2 = new proxy32(modelo2);
        
        //Se crean los controladores
        Controlador1 controlador1 = new Controlador1(vista1,modelo1,prox1_2,prox1_3);
        Controlador2 controlador2 = new Controlador2(vista2,modelo2,prox1_2);
        Controlador3 controlador3 = new Controlador3(vista3,modelo3,prox1_3,prox3_2);
        
        controlador1.iniciar();
        controlador2.iniciar();
        controlador3.iniciar();
        vista2.setVisible(true);
       
    }
}
