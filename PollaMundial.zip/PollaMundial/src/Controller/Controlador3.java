/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Modelo3;
import View.Vista3;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Acer
 */
public class Controlador3 implements ActionListener{
    
    private Vista3 vista3;
    private Modelo3 modelo3;
    private proxy13 proxy;
    private proxy32 proxy2;

    public Controlador3(Vista3 vista3, Modelo3 modelo3, proxy13 proxy, proxy32 proxy2){
        this.vista3 = vista3;
        this.modelo3 = modelo3;
        this.proxy = proxy;
        this.proxy2 = proxy2;
        this.vista3.btnnuevo.addActionListener(this);
    }
    
    public void iniciar(){
        this.vista3.setTitle("Menu");
        this.vista3.setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.vista3.btnnuevo)
        {
            String name = JOptionPane.showInputDialog(null, "Introduce un nombre de usuario: ");
            
            if(name!=null && !name.equals(""))//Se verifica que el nombre no sea null ni vacio
            {
                if(this.modelo3.nuevo_usuario(name))//Confirma que otro archivo con el mismo nombre no exista
                {
                    this.proxy2.pasar_ruta(this.getClass().getName(),this.modelo3.getRuta());//Para crear el archivo al final se lo pasa a modelo2
                    this.proxy.open_vista1(this.getClass().getName());
                    this.vista3.dispose();
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Su usuario no puede ser vacio ni nulo", "Atencion!", 1);
            }
        }
        else if(e.getSource()==this.vista3.btncalificar)
        {
            
        }
    }
    
}
