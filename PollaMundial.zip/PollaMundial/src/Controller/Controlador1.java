/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Modelo1;
import View.Vista1;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import javax.swing.JOptionPane;

/**
 *
 * @author Acer
 */
public class Controlador1 implements ActionListener{
    
    private Vista1 vista1;
    private Modelo1 modelo1;
    private proxy12 proxy2;
    private proxy13 proxy3;
    private int i; //Controla los enfrentamientos
    private int j;//Controla el nombre del grupo
    private String nombre = "usuario1";

    public Controlador1(Vista1 vista1, Modelo1 modelo1, proxy12 proxy2, proxy13 proxy3) {
        this.vista1 = vista1;
        this.modelo1 = modelo1;
        this.proxy2 = proxy2;
        this.proxy3 = proxy3;
        this.vista1.btnnext.addActionListener(this);
        this.vista1.btnback.addActionListener(this);
        i=0;
        j=0;
        this.modelo1.grupo(i,j);
    }
    
    public void iniciar(){
        this.vista1.setTitle("Fase de grupos");
        this.vista1.setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.vista1.btnnext)
        {
            //si aun no llega al grupo H
            if(i<28)
            {
                //if(this.modelo1.comprobar())//Comprueba que todos los txt sean numeros
                //{
                //    this.modelo1.guardar(i,nombre); //Guarda las predicciones
                    this.modelo1.limpiartxt(); //Limpiar los txt para los siguientes grupos
                    this.i = this.i+4; 
                    this.j = this.j+1;
                    this.modelo1.grupo(i,j);
                //}
            }
            else //Si esta en el grupo H
            {
                //if(this.modelo1.comprobar())//Comprueba que todos los txt sean numeros
                //{
                //    this.modelo1.guardar(i,nombre); //Guarda las predicciones
                    //this.modelo1.limpiartxt(); //Limpiar los txt para los siguientes grupos
                    this.proxy2.open_vista2(this.getClass().getName());
                    this.vista1.dispose();
                    
                //}
            }
            
        }
        else if(e.getSource()==this.vista1.btnback)
        {
            if(i>0)
            {
                this.i = this.i-4; 
                this.j = this.j-1;
                this.modelo1.grupo(i,j);
            }
            else
            {
                int salir = JOptionPane.showConfirmDialog(null, "¿Quieres salir? \n Se borrarran todos los avances realizados", "salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
		//0=yes, 1=no
		if(salir == 0) {
		  this.proxy3.open_vista3(this.getClass().getName());
                    this.vista1.dispose();
                }              
            }
        }
    }
   
}
