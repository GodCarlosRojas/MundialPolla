/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import View.Vista1;
import View.Vista2;

/**
 *
 * @author Acer
 */
public class proxy12 {
    
    private Vista1 vista1;
    private Vista2 vista2;

    public proxy12(Vista1 vista1, Vista2 vista2) {
        this.vista1 = vista1;
        this.vista2 = vista2;
    }
    
   public void open_vista1(String nombre){
       if(nombre.equals("Controller.Controlador2"))
       {
           vista1.setVisible(true);
       }
   } 
   
   public void open_vista2(String nombre){
       if(nombre.equals("Controller.Controlador1"))
       {
           vista2.setVisible(true);
       }
   }
}
