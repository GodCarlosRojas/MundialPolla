/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Modelo2;
import View.Vista2;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Acer
 */
public class Controlador2 implements ActionListener{
    
    private Vista2 vista2;
    private Modelo2 modelo2;
    private proxy12 proxy;
    int k = 0; //Variable que verifica en que etapa de final esta el ususario

    public Controlador2(Vista2 vista2, Modelo2 modelo2, proxy12 proxy) {
        this.vista2 = vista2;
        this.modelo2 = modelo2;
        this.proxy = proxy;
        this.vista2.btnback.addActionListener(this);
        this.vista2.btnterminar.addActionListener(this);
        this.vista2.btnflechaizquierda.addActionListener(this);
        this.vista2.btnflechaderecha.addActionListener(this);
        this.modelo2.nombres();
    }
    
    public void iniciar(){
        this.vista2.setTitle("Finales");
        this.vista2.setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.vista2.btnflechaderecha)
        { 
            //octavos
            if(this.k==0)
            {
                //if(this.modelo2.comprobar())//Comprueba que no se repitan equipos
                //{
                    try
                    {
                        this.modelo2.calificar_octavos();
                        
                    }catch(NumberFormatException x)
                    {
                        error();
                    }
                /*}
                else
                {
                    JOptionPane.showMessageDialog(null, "El mismo equipo NO puede \n participar 2 veces en octavos de final", "Error", 0);
                }*/
            }//cuartos
            else if(this.k==1)
            {
                
            }//semifinales
            else if(this.k==2)
            {
                
            }//final
            else
            {
                
            }
        }
        else if(e.getSource()==this.vista2.btnback)
        {
            this.proxy.open_vista1(this.getClass().getName());
            this.vista2.dispose();
        }
        else if(e.getSource()==this.vista2.btnterminar)
        {
            
        }
    }
    
    public static void error()
    {
        JOptionPane.showMessageDialog(null, "No puede haber empates \n ni vacios en el marcador principal", "Error", 0);
    }
}
