/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import View.Vista1;
import View.Vista3;

/**
 *
 * @author Acer
 */
public class proxy13 {
    
    private Vista1 vista1;
    private Vista3 vista3;

    public proxy13(Vista1 vista1, Vista3 vista3) {
        this.vista1 = vista1;
        this.vista3 = vista3;
    }
    
   public void open_vista1(String nombre){
       if(nombre.equals("Controller.Controlador3"))
       {
           this.vista1.setVisible(true);
       }
   } 
   
   public void open_vista3(String nombre){
       if(nombre.equals("Controller.Controlador1"))
       {
           this.vista3.setVisible(true);
       }
   }
}
