/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Modelo2;
/**
 *
 * @author Acer
 */
public class proxy32 {
    
    private Modelo2 modelo2;

    public proxy32(Modelo2 modelo2) {
        this.modelo2 = modelo2;
    }
    
    public void pasar_ruta(String name, String ruta){
        if(name.equals("Controller.Controlador3"))
        {
            this.modelo2.setRuta(ruta);
        }
    }
}
